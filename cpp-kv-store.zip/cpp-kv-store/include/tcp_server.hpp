#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <unistd.h>

#include <cstring>
#include <iostream>
#include <mutex>
#include <shared_mutex>
#include <string>
#include <thread>
#include <unordered_map>

#include "kv_store.hpp"

class TCPServer {
private:
    int server_socket;
    int port;
    std::shared_mutex smtx;
    KVStore store;

    void process_request(std::string& request, std::string& response);
    void handle_client(int client_socket);

public:
    TCPServer(int port);
    void start();
};