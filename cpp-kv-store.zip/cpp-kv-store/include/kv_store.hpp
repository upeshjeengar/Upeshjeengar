#pragma once

#include <mutex>
#include <shared_mutex>
#include <string>
#include <unordered_map>

class KVStore {
private:
    std::unordered_map<std::string, std::string> umap;
    std::shared_mutex smtx;

public:
    KVStore();
    void set(std::string&& key, std::string&& value, std::string& response);
    void get(const std::string& key, std::string& response);
    void del(const std::string& key, std::string& response);
};