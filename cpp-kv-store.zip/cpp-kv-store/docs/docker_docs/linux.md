1. Start the Server (Terminal 1)

```Bash
docker compose up -d server
```

2. Run the Automated Tests (Terminal 2)
Whenever you want to run your python/C++ test suite, run this. It will spin up, execute run_tests.sh, print the results, and automatically delete itself (--rm) when finished.

```Bash
docker compose --profile testing up tester --build
```

3. Test Manually (Terminal 3)
Because port 8080 is exposed, you can use netcat (or Telnet/PuTTY on Windows) directly from your host machine to talk to the containerized server.

```Bash
nc localhost 8080
```


#### To stop the server from that setup, it depends on whether you just want to pause it or completely tear it down to clean up your environment.

Here are the two ways to do it:

1. The "Pause" (Stop but keep the container)
If you just want to stop the server from running but keep the container exactly as it is (so it starts up instantly next time), run:

```Bash
docker compose stop server
```

To start it back up later, you just run docker compose start server.

2. The "Tear Down" (Stop and remove everything)
If you are done testing for the day and want to completely destroy the container and the internal network it created (this is usually the best practice to avoid conflicts later), run:

```Bash
docker compose down
```