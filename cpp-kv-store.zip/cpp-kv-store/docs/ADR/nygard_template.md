Title: A short, imperative noun phrase (e.g., "ADR 5: Use Lock-Free Ring Buffers for Inter-Thread Communication").

Status: What state the decision is in (e.g., Proposed, Accepted, Deprecated, Superseded).

Context: The forces at play, the technical constraints, and the problem you are solving. This is where you explain the "why."

Decision: The actual choice you made.

Consequences: The resulting context after applying the decision. This must include both positives (e.g., "Latency dropped to 10µs") and negatives (e.g., "Increased memory footprint").