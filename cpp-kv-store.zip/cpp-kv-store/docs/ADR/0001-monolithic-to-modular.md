### ADR 1 : Conversion of monolithic code to modular code

Status : Done 

Context : Readability and maintainabilty of the codebase.

Decision: Converted the single file codebase(monolithic code) to readable and maintainable code(modular code)

Consequences:
Results Comparison:
|Performance Criteria | Monolithic code | Modular Code |
| --- | --- | --- |
|Peak Throughput (Stress)	|380,735 req/sec	|387,476 req/sec|
|Sustained Throughput (10 Min)	|266,859 req/sec |287,632 req/sec|
|Total Endurance Requests	|167.2 Million	|177.2 Million|
|Average Latency	|10.366 µs	|9.856 µs|
|Median Latency (p50)	|10.111 µs	|9.735 µs|
|Fast Tail Latency (p95)	|12.218 µs	|10.748 µs|
|Deep Tail Latency (p99)	|15.284 µs	|14.084 µs|
|Absolute Min Latency	|8.453 µs	|8.627 µs|
|Absolute Max Latency	|120.819 µs	|115.178 µs|
|Failures / Dropped Packets |	0	|0|