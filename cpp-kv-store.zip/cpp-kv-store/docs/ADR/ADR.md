# ADR (Architecture Decision Record)

| Sl. no. | Decision | Impact or tradeoffs |  
| --- | --- | --- |
|1| Converted monolithic program to modular porgram| Old Stats : 1. Peak, Throughput (Stress Test)
Speed: 377,268 requests/second

Total Time: 2.65 seconds to process 1,000,000 requests

Concurrency: 100 threads (Persistent keep-alive connections)

Failures: 0

2. Precision Latency (Microseconds)

Average Latency: 10.01 µs

p50 (Median): 9.78 µs

p95 (Fast): 12.08 µs

p99 (Tail): 16.00 µs

Extremes: Min: 8.72 µs | Max: 140.49 µs

3. Sustained Endurance (10-Minute Run)

Total Volume: 162,032,080 requests handled successfully

Sustained Speed: 267,648 requests/second (average over 10 mins)

Failures: 0

4. Reliability & Integrity

Write Speed: Wrote 10,000 keys in 0.13 seconds.

Data Integrity: 100% success on ACID-lite read-back verification.

TCP Resilience: Flawlessly handled chaotic network streams (drip-feed fragmentation, sticky batch writes, and random boundary splits).     |