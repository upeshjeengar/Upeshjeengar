# C++ Key-Value Store

This is a high-performance, multithreaded key-value store server developed in modern C++ that handles multiple concurrent client connections over raw TCP.

The server currently supports three types of operations:

 1. `SET key value` (Response: "OK")
 2. `GET key` (Response: the value if found, otherwise "NOT FOUND")
 3. `DEL key` (Response: "OK" if found and deleted, otherwise "NOT FOUND")

---

### Features & Architecture
Designed for low latency and high throughput under heavy load:
* **Thread-per-Connection:** Automatically detaches a new thread for every incoming client connection.
* **Concurrent Reads:** Utilizes `std::shared_mutex` (Read-Write Locks) to allow multiple clients to perform `GET` operations simultaneously without blocking, while strictly locking `SET` and `DEL` operations to maintain data integrity.
* **Zero-Copy Overheads:** Uses move semantics (`std::move`) to transfer keys and values into the internal map, minimizing unnecessary memory allocations.
* **Architecture Decision Records:** For a deeper dive into the engineering choices (like moving from a monolithic to a modular design), see the [ADR Documentation](docs/ADR/ADR.md).

---

### Dependencies
* C++17 compiler (GCC/Clang)
* CMake (>= 3.15)
* Python 3 (for running chaos and integrity tests)
* Docker (Optional, but required to run the server on Windows or macOS. The server is natively developed and optimized for Linux/Fedora).

---

### How to Run

#### 1. Run Manually (Linux / Fedora)

**i. Build the Server**
The project is configured with CMake to automatically apply heavy compiler optimizations (like `-O3` and Link-Time Optimization).
```bash
# Generate build files and compile
cmake -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build -j
```

**ii. Run the Server**
You can run the compiled executable directly, or use the provided helper script:
```bash
./build/kv_server
# OR use the script: ./scripts/run_server.sh
```

**iii. Clean Up**
To clean your build environment and remove generated test binaries:
```bash
./scripts/clean_setup.sh
```

#### 2. Run Using Docker (Cross-Platform)
To run the server and test suite on any OS (Linux, macOS, Windows) without installing dependencies locally, use Docker Compose.
**i. Start the Server:**
```bash
docker compose up -d server
```
**ii. Shut Down and Clean Up:**
```bash
docker compose down
```

---

### Client Testing
#### 1. Manual Testing
You can interact with the running server using netcat(`nc`):
```bash
nc localhost 8080
# Type: SET mykey 123
# Type: GET mykey
```

#### 2. Automated Testing Suite
The project includes a robust, custom-built testing suite featuring 5 different stress and resilience tests.

_If running via Docker:_
```bash
docker compose --profile testing up tester --build
```

_If running natively on Linux:_
```bash
./scripts/run_tests.sh
```

---

### Performance Benchmarks
The server has been rigorously tested for latency, throughput, and long-term stability. Below are the results from the integrated benchmark suite simulating 100 concurrent persistent connections.

| Metric | Measurement | Description |
| --- | --- | --- |
| Peak throughput | ~361,162 req/sec | Maximum burst speed under a Keep-Alive connection stress test (1 Million requests).|
|Average Latency | 11.65 microsecond | Average round-trip time for a request.|
|Tail Latency(p95) | 17.54 microsecond | 95% of requests are processed faster than this threshold.|
|Tail Latency(p99) | 17.54 microsecond | 99% of requests are processed faster than this threshold.|
| Endurance | 182.6 Million Reqs | Total requests handled continuously over 10 minutes.|
| Failures | 0 | Zero dropped packets or crashes under maximum load.|
| Data Integrity | 100 % | Successfully passed ACID-lite write-read verification and TCP stream chaos testing (fragmentation/sticky packets).|

_(Note: Performance scales with your CPU hardware and OS networking stack. Linux natively handles high-concurrency TCP sockets faster than WSL/Windows)._