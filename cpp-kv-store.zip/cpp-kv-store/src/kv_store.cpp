#include "../include/kv_store.hpp"

KVStore::KVStore() {}

void KVStore::set(std::string&& key, std::string&& value, std::string& response) {
    std::unique_lock<std::shared_mutex> lock(smtx);
    // std::cout << command << " " << key << " " << value << "\n" << std::flush;
    // store in the map;
    // um.insert_or_assign(key, value); this create copy of key and value again for
    // assigning in unordered map we are decreasing that unnecessary load using move becuase
    // these key value will be destroyed or will be of no use. So, we should use them.
    umap.insert_or_assign(std::move(key), std::move(value));
    response = "OK\n";
}

void KVStore::get(const std::string& key, std::string& response) {
    std::shared_lock<std::shared_mutex> lock(smtx);
    auto itr = umap.find(key);
    if (itr != umap.end()) {
        response = itr->second + '\n';
        return;
    }

    response = "NOT FOUND\n";
}

void KVStore::del(const std::string& key, std::string& response) {
    std::unique_lock<std::shared_mutex> lock(smtx);
    if (umap.erase(key)) {
        response = "OK\n";
        return;
    }
    response = "NOT FOUND\n";
}
