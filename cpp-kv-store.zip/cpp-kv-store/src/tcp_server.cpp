#include "../include/tcp_server.hpp"

#define LISTEN_BACKLOG 50

#define handle_error(msg)   \
    do {                    \
        perror(msg);        \
        exit(EXIT_FAILURE); \
    } while (0)

TCPServer::TCPServer(int port_no) {
    port = port_no;
    server_socket = -1;
}

void TCPServer::start() {
    // 1.0 server socket creation
    server_socket = socket(AF_INET, SOCK_STREAM, 0);
    if (server_socket == -1) handle_error("socket");

    // 1.1 Set SO_REUSEADDR
    // Normally it takes some time to restart
    // This allows us to restart the server immediately without waiting
    // for the OS to release the port (TIME_WAIT state).
    int opt = 1;
    if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt))) {
        std::cerr << "Setsockopt failed.\n";
        return;
    }

    // 2.0 Bind to port
    struct sockaddr_in server_addr;
    memset(&server_addr, 0, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(static_cast<uint16_t>(port));

    if (bind(server_socket, reinterpret_cast<struct sockaddr*>(&server_addr),
             sizeof(server_addr)) == -1)
        handle_error("bind");

    // SOMAXCONN is crucial for high throughput (basically the higher backlog capacity)
    // a small backlog capacity like 5 causes connection refusals under load.
    if (listen(server_socket, SOMAXCONN) == -1) handle_error("listen");

    std::cout << "Listening started.\n";

    /* Now we can accept incoming connections one at a time using accept(2). */

    struct sockaddr_in client_addr;

    while (true) {
        socklen_t client_len = sizeof(client_addr);
        int client_socket =
            accept(server_socket, reinterpret_cast<struct sockaddr*>(&client_addr), &client_len);
        if (client_socket >= 0) {
            std::thread t([this, client_socket]() { this->handle_client(client_socket); });
            // std::thread t(&TCPServer::handle_client, this, client_socket);
            t.detach();
        } else {
            handle_error("accept");
        }
    }

    if (close(server_socket) == -1) handle_error("close");
}

void TCPServer::handle_client(int client_socket) {
    char temp_buffer[1024];
    std::string request, response;

    while (true) {
        ssize_t bytes_read = recv(client_socket, temp_buffer, sizeof(temp_buffer) - 1, 0);

        if (bytes_read <= 0) {
            close(client_socket);
            return;  // client closed connection or error.
        }

        for (int i = 0; i < bytes_read; i++) {
            if (temp_buffer[i] != '\n') {
                request.push_back(temp_buffer[i]);
            } else {
                process_request(request, response);
                send(client_socket, response.c_str(), response.size(), 0);
                request.clear();
                response.clear();
            }
        }
    }
}

void TCPServer::process_request(std::string& request, std::string& response) {
    size_t n = request.size();
    std::string command, key, value;
    bool valid_command_length = true;

    // We know key and value won't be larger than the whole request
    key.reserve(n);
    value.reserve(n);

    size_t i = 0;

    // pass all the spaces before command
    while (i < n && request[i] == ' ') {
        i++;
    }

    // extract command
    while (i < n && request[i] != ' ') {
        command.push_back(request[i]);
        if (command.size() > 3) {
            std::cout << command << '\n';
            response = "INVALID COMMAND 1\n";
            valid_command_length = false;
            break;
        }
        i++;
    }

    if (valid_command_length) {
        // skip all blank spaces
        while (i < n && request[i] == ' ') {
            i++;
        }

        // extract key
        while (i < n && request[i] != ' ') {
            key.push_back(request[i]);
            i++;
        }

        // writing into map
        if (command == "SET") {
            // skip all blank spaces
            while (i < n && request[i] == ' ') {
                i++;
            }

            // extract value
            while (i < n) {
                value.push_back(request[i]);
                i++;
            }

            // std::cout << command << " " << key << " " << value << "\n" << std::flush;
            // store in the map;
            // um.insert_or_assign(key, value); this create copy of key and value again for
            // assigning in unordered map we are decreasing that unnecessary load using move becuase
            // these key value will be destroyed or will be of no use. So, we should use them.

            // Remove trailing carriage return if it exists (Windows compatibility)
            if (!value.empty() && value.back() == '\r') {
                value.pop_back();
            }

            store.set(std::move(key), std::move(value), response);

        } else if (command == "GET") {
            // std::cout << command << " " << key << "\n" << std::flush;
            if (!key.empty() && key.back() == '\r') {
                key.pop_back();
            }

            store.get(key, response);

        } else if (command == "DEL") {
            if (!key.empty() && key.back() == '\r') {
                key.pop_back();
            }

            store.del(key, response);

        } else {
            response = "INVALID COMMAND 2\n";
        }
    }
}