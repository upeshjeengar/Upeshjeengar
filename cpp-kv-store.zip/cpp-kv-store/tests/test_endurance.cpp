// tests/test_endurance.cpp
// -----------------------------------------------------------------------------
// GOAL: Verify Long-Term Stability (Memory Leaks, Deadlocks, Thrashing).
// METHODOLOGY:
//   1. Run for a sustained period (e.g., 10 minutes).
//   2. Use 100 concurrent threads to ensure race conditions trigger if present.
//   3. Monitor "Requests Per Second" in real-time.
//      - If RPS drops over time -> Possible Memory Leak or CPU Throttle.
//      - If RPS hits zero -> Deadlock.
// -----------------------------------------------------------------------------

#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstring>
#include <iomanip>
#include <iostream>
#include <thread>
#include <vector>

// CONFIGURATION
const char* SERVER_IP = "127.0.0.1";
const int SERVER_PORT = 8080;
const int TEST_DURATION_SEC = 600;  // 10 Minutes
const int THREADS = 100;            // 100 Concurrent Connections

std::atomic<long long> total_success(0);
std::atomic<long long> total_fail(0);
std::atomic<bool> keep_running(true);

void worker_thread(int thread_id) {
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) return;

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        close(sock);
        return;
    }

    char buffer[1024];
    long long local_count = 0;

    // Run continuously until the main timer tells us to stop
    while (keep_running) {
        std::string command;
        // 90% Reads, 10% Writes to simulate real load
        if (local_count % 10 == 0) {
            command = "SET key_" + std::to_string(thread_id) + "_" + std::to_string(local_count) +
                      " value_" + std::to_string(local_count) + "\n";
        } else {
            command =
                "GET key_" + std::to_string(thread_id) + "_" + std::to_string(local_count) + "\n";
        }

        if (send(sock, command.c_str(), command.size(), 0) < 0) break;
        if (recv(sock, buffer, sizeof(buffer), 0) <= 0) break;

        total_success++;
        local_count++;
    }
    close(sock);
}

void monitor_thread() {
    auto start_time = std::chrono::high_resolution_clock::now();
    long long previous_count = 0;

    std::cout << "\n\n============================================================\n";
    std::cout << "         TEST: ENDURANCE STABILITY (10 MIN)                 \n";
    std::cout << "============================================================\n";
    std::cout << "Target:       " << SERVER_IP << ":" << SERVER_PORT << "\n";
    std::cout << "Threads:      " << THREADS << "\n";
    std::cout << "------------------------------------------------------------\n";
    // std::cout << "|   Elapsed   |    Total Req     |     Req/Sec     |\n";
    // std::cout << "------------------------------------------------------------\n";
    std::cout << "PLEASE WAIT FOR 10 MINUTES ...\n";
    std::cout << "------------------------------------------------------------\n";
    std::cout << "| Minutes Elapsed | Total requests Completed | Average RPS (Request per second) |"
              << "\n"
              << std::flush;

    // Update the console every second with current stats
    for (int i = 0; i < TEST_DURATION_SEC; ++i) {
        std::this_thread::sleep_for(std::chrono::seconds(1));

        long long current_count = total_success.load();
        long long delta = current_count - previous_count;  // Requests in the last second
        previous_count = current_count;

        // std::cout << "| " << std::setw(6) << (i + 1) << "s     | " << std::setw(14) <<
        // current_count
        //           << "   | " << std::setw(12) << delta << "    |\r" << std::flush;

        if (i % 60 == 59) {
            int minutes_elapsed = (i / 60) + 1;
            long long avg_rps = current_count / (minutes_elapsed * 60);

            std::cout << "| " << std::setw(15) << minutes_elapsed << " | " << std::setw(24)
                      << current_count << " | " << std::setw(32) << avg_rps << " |\n"
                      << std::flush;
        }
    }
    keep_running = false;  // Stop all workers
    std::cout << "\n------------------------------------------------------------\n";
}

int main() {
    std::vector<std::thread> threads;

    // Start Monitor
    std::thread monitor(monitor_thread);

    // Start Workers
    for (int i = 0; i < THREADS; ++i) {
        threads.emplace_back(worker_thread, i);
    }

    // Wait for Monitor to finish (after 600s)
    monitor.join();

    // Wait for workers to cleanup
    for (auto& t : threads) {
        t.join();
    }

    std::cout << "                          RESULTS\n";
    std::cout << "------------------------------------------------------------\n";
    std::cout << "Total Requests: " << total_success.load() << "\n";
    std::cout << "Failures:       " << total_fail.load() << "\n";
    std::cout << "============================================================\n\n\n";

    return 0;
}