// tests/benchmark_throughput.cpp
// -----------------------------------------------------------------------------
// GOAL: Measure the maximum Requests Per Second (RPS) the server can handle.
//
// METHODOLOGY:
//   1. Concurrency: Launch 100 parallel threads to simulate 100 active users.
//   2. Protocol: Use "Keep-Alive" (Persistent Connections).
//      - We connect ONCE and send thousands of requests.
//      - This stresses the DB Engine, not the OS TCP Handshake (3-way handshake).
//   3. Workload: Mixed 90% Reads (GET) / 10% Writes (SET).
//      - This mimics real-world cache usage patterns (e.g., Redis).
//   4. Measurement: Use std::atomic for lock-free counting to avoid
//      the test client becoming the bottleneck.
//   5.Diagnostics: If requests fail, we capture the 'errno' to identify
//      if the server Crashed (ECONNRESET) or was Unreachable (ECONNREFUSED).
// -----------------------------------------------------------------------------

#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <atomic>
#include <chrono>
#include <cstring>
#include <iostream>
#include <thread>
#include <vector>

// CONFIGURATION
const char* SERVER_IP = "127.0.0.1";
const int SERVER_PORT = 8080;
const int TOTAL_REQUESTS = 1000000;  // 1 Million total requests
const int THREADS = 100;             // 100 Concurrent Connections

// Atomic counters allow multiple threads to update stats without mutex locking overhead
// If we used a mutex here, the test script itself would slow down.
std::atomic<int> success_count(0);
std::atomic<int> fail_count(0);
std::atomic<int> last_error(0);  // Stores the reason for failure

void worker_thread(int requests_per_thread) {
    // 1. OPEN CONNECTION (Once per thread)
    // We do NOT open/close per request. That would benchmark the OS TCP stack,
    // not our database engine's throughput.
    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        last_error = errno;  // Capture OS error
        fail_count += requests_per_thread;
        return;
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        last_error = errno;  // Capture why we couldn't connect
        // If server is down, count all intended requests as failures
        fail_count += requests_per_thread;
        close(sock);
        return;
    }

    char buffer[1024];

    // 2. SPAM REQUESTS (Keep-Alive)
    for (int i = 0; i < requests_per_thread; ++i) {
        std::string command;
        // MIXED WORKLOAD SIMULATION:
        // Real databases are read-heavy. We simulate 90% GET, 10% SET.
        if (rand() % 10 == 0) {
            command = "SET key_" + std::to_string(i) + " value_" + std::to_string(i) + "\n";
        } else {
            command = "GET key_" + std::to_string(i) + "\n";
        }

        // Send Command
        if (send(sock, command.c_str(), command.size(), 0) < 0) {
            last_error = errno;  // Capture why we failed
            fail_count++;
            break;
        }

        // Wait for Response (Synchronous)
        // We MUST read the response to clear the buffer, otherwise
        // the kernel buffer fills up and the connection hangs.

        ssize_t bytes_received = recv(sock, buffer, sizeof(buffer), 0);

        if (bytes_received == 0) {
            // Case 1: Server closed connection cleanly (but unexpectedly for us)
            last_error = ECONNRESET;  // Force "Connection reset by peer"
            fail_count++;
            break;
        } else if (bytes_received < 0) {
            // Case 2: Actual OS Error (e.g., Timeout)
            last_error = errno;
            fail_count++;
            break;
        }

        success_count++;
    }

    // 3. CLOSE CONNECTION
    close(sock);
}

int main() {
    std::cout << "\n\n============================================================\n";
    std::cout << "         TEST: THROUGHPUT BENCHMARK (STRESS)                \n";
    std::cout << "============================================================\n";
    std::cout << "Mode:         Persistent Connections (Keep-Alive)\n";
    std::cout << "Requests:     " << TOTAL_REQUESTS << "\n";
    std::cout << "Threads:      " << THREADS << "\n";

    auto start_time = std::chrono::high_resolution_clock::now();

    std::vector<std::thread> threads;
    int req_per_thread = TOTAL_REQUESTS / THREADS;

    for (int i = 0; i < THREADS; ++i) {
        threads.emplace_back(worker_thread, req_per_thread);
    }

    for (auto& t : threads) {
        t.join();
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    std::chrono::duration<double> duration = end_time - start_time;
    double throughput = success_count / duration.count();

    std::cout << "------------------------------------------------------------\n";
    std::cout << "                          RESULTS\n";
    std::cout << "------------------------------------------------------------\n";
    std::cout << "Time:         " << duration.count() << " seconds\n";
    std::cout << "Throughput:   " << throughput << " req/sec\n";
    std::cout << "Failures:     " << fail_count << "\n";

    if (fail_count > 0) {
        std::cout << "------------------------------------------------------------\n";
        std::cout << "DIAGNOSTIC: Last System Error was '" << strerror(last_error) << "'\n";
        std::cout << "Hint: 'Connection refused' = Server Down.\n";
        std::cout << "      'Connection reset'   = Server Crashed/Killed.\n";
    }

    std::cout << "============================================================\n\n\n";

    return 0;
}