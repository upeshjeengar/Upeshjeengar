# Performance & Testing Suite

This directory contains the benchmarking toolkit used to validate the C++ Key-Value Store.  

It focuses on **Latency Precision** (Microseconds), **High-Throughput Stress** (Load), and **Long-Term Stability** (Endurance).

---

## 📊 Benchmark Results (Lab Report)

### 1. Performance Evolution (Summary)
Tracking the high-level impact of architectural changes between versions.

| Version | Peak Throughput | Latency (p99) | Endurance (10 min) | Engineering Impact |
| :--- | :--- | :--- | :--- | :--- |
| **v2.1** | **244,598 req/s** | **13.39 µs** | **99 Million+ Reqs** | Baseline Thread Pool. |
| **v2.2** | **249,942 req/s** | **14.70 µs** | **100 Million+ Reqs** | Zero-Copy Parser, 1MB Limit. |
| **v2.3** | **240,272 req/s** | **15.98 µs** | **99 Million+ Reqs** | Improved stability and error handling.|


### 2. Detailed Metrics

#### Version 2.1 (Baseline)
*The initial implementation using `stringstream` and standard vectors.*

| Metric | Measurement | Description | Proof |
| :--- | :--- | :--- | :--- | 
| **Peak Throughput** | **244,598 req/s** | Maximum burst speed (Keep-Alive). |  [View](../docs/images/throughput/v2.1.png) |
| **Latency** | **13.39 µs (p99)** | Min: 8.65µs / Median: 9.77µs / Max: 118.7µs | [View](../docs/images/latency/v2.1.png) |
| **Endurance** | **99,129,639 Reqs** | Total requests served in 10 minutes. | [View](../docs/images/endurance/v2.1.png) |

#### Version 2.2 (Optimized)
*The current build with Zero-Copy parsing, Stream Safety, and Security limits.*

| Metric | Measurement | Description | Proof |
| :--- | :--- | :--- | :--- | 
| **Peak Throughput** | **249,942 req/s** | Maximum burst speed (Keep-Alive). | [View](../docs/images/throughput/v2.2.png) |
| **Latency** | **14.70 µs (p99)** | Min: 9.78µs / Median: 10.12µs / Max: 146.6µs | [View](../docs/images/latency/v2.2.png) |
| **Endurance** | **100,047,601 Reqs** | Total requests served in 10 minutes. | [View](../docs/images/endurance/v2.2.png) |


#### Version 2.3 (Stable)
*Added full code comments, simplified the setup scripts, and improved error handling. Fixed a critical SIGPIPE bug where a single bad client could crash the server.*

| Metric | Measurement | Description | Proof |
| :--- | :--- | :--- | :--- | 
| **Peak Throughput** | **240,272 req/s** | Maximum burst speed (Keep-Alive). | [View](../docs/images/throughput/v2.3.png) |
| **Latency** | **15.85 µs (p99)** | Min: 9.27µs / Median: 10.70µs / Max: 106.2µs | [View](../docs/images/latency/v2.3.png) |
| **Endurance** | **99,052,792 Reqs** | Total requests served in 10 minutes. | [View](../docs/images/endurance/v2.3.png) |

---
## ⚙️ Test Methodology

We use a custom-built C++ benchmarking suite to avoid the overhead of external tools like Jmeter.

* **Concurrency:** 100 Persistent Threads (simulating 100 active users).
* **Protocol:** Raw TCP with Keep-Alive (reusing sockets to stress the engine, not the OS handshake).
* **Payload:** Random Key Access (Keys: `key_0` to `key_1000`).
* **Safety:** Verifies data integrity by writing 10,000 keys and reading them back.
* **Resilience:** Validates TCP stream handling against **Sticky Packets**, **Fragmentation**, and **Slow Clients** (Chaos Test).

---

## 📂 Tool Overview

| Tool | File | Purpose |
| :--- | :--- | :--- |
| **Throughput** | `benchmark_throughput.cpp` | Floods the server to find the maximum **Requests Per Second (RPS)**. |
| **Latency** | `benchmark_latency.cpp` | Measures precise response times (Min, Avg, p99). |
| **Endurance** | `test_endurance.cpp` | Runs for 10 minutes to detect **Memory Leaks** or **Deadlocks**. |
| **Integrity** | `test_integrity.py` | Python script to verify data correctness (Write -> Read -> Compare). |
| **Chaos**	| `test_stream_chaos.py`	| Stress Tests TCP: Fragmentation, Sticky Packets, and Partial Reads.|

---

## ⚠️ Performance Note
The results below were achieved on a **Linux Fedora (Intel Core i5)** system with **Balanced Power Mode** enabled and the charger connected.

Your actual results may vary based on:
* **Hardware:** Number of CPU cores and Clock Speed.
* **OS:** Linux typically performs faster than Windows/WSL for high-concurrency sockets.
* **Thermals:** Performance will drop if the CPU throttles due to heat (see "Sustained" vs "Peak" below).

---

## 🚀 Usage

### 1. Compile the C++ Tools
Run from the project root:
```bash
# Throughput benchmark
g++ -O3 -pthread tests/benchmark_throughput.cpp -o tests/bench_throughput

# Latency benchmark
g++ -O3 -pthread tests/benchmark_latency.cpp -o tests/bench_latency

# Endurance test
g++ -O3 -pthread tests/test_endurance.cpp -o tests/test_endurance
```

### 2. Run the Test Suite
Start the server before running the tests.

#### Manual way
##### Step 1: Verify Correctness
```bash
python3 tests/test_integrity.py
```
![Integrity test result](../docs/images/integrity/v2.3.png)

##### Step 2: TCP Chaos Test (Fragmentation & Sticky Packets)
```bash
python3 tests/test_stream_chaos.py
```
![TCP chaos test result](../docs/images/TCP_choas_test/v2.3.png)

##### Step 3: Measure Latency
```bash
./tests/bench_latency
```
![Latency test result](../docs/images/latency/v2.3.png)

##### Step 4: Measure Maximum Throughput
```bash
./tests/bench_throughput
```
![Throughput test result](../docs/images/throughput/v2.3.png)

##### Step 5: 10-Minute Stability Test
```bash
./tests/test_endurance
```
![Endurance test result](../docs/images/endurance/v2.3.png)

#### Automated way
Shortcut to run all tests in one go.
```bash
./scripts/run_tests
```