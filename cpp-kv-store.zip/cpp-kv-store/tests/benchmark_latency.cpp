// tests/benchmark_latency.cpp
// -----------------------------------------------------------------------------
// GOAL: Measure the precise response time of the server (Microseconds).
// METHODOLOGY:
//   1. Warmup:Run 100 requests first.
//      - WHY? The first few requests are always slow (CPU cache misses,
//        TCP Slow Start, OS context switching). Benchmarking "cold" code is invalid.
//   2. Measurement: Run 10,000 requests sequentially (Blocking I/O).
//      - We measure the round-trip time (RTT) from Send -> Recv.
//   3. Statistical Analysis:
//      - We do NOT just rely on "Average" (Mean), which hides outliers.
//      - We calculate p50 (Median), p95, and p99 (Tail Latency).
//      - p99 (99th Percentile): 99% of requests are faster than this.
//        It represents the "Tail Latency" threshold for the slowest 1% of users.
// -----------------------------------------------------------------------------

#include <arpa/inet.h>
#include <sys/socket.h>
#include <unistd.h>

#include <algorithm>
#include <chrono>
#include <cmath>
#include <cstring>
#include <iostream>
#include <numeric>
#include <vector>

// command to compile program for best results
// g++ -O3 tests/latency_test.cpp -o tests/latency_check

// CONFIGURATION
const char* SERVER_IP = "127.0.0.1";
const int SERVER_PORT = 8080;
const int NUM_REQUESTS = 10000;  // Sample size for statistical significance

int main() {
    std::cout << "\n\n============================================================\n";
    std::cout << "         TEST: PRECISION LATENCY ANALYSIS                   \n";
    std::cout << "============================================================\n";
    std::cout << "Samples:      " << NUM_REQUESTS << "\n";
    std::cout << "Warmup:       100 Requests\n";

    std::vector<double> latencies;  // Store time in microseconds
    latencies.reserve(NUM_REQUESTS);

    int sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0) {
        perror("Socket failed");
        return 1;
    }

    struct sockaddr_in server_addr;
    server_addr.sin_family = AF_INET;
    server_addr.sin_port = htons(SERVER_PORT);
    inet_pton(AF_INET, SERVER_IP, &server_addr.sin_addr);

    if (connect(sock, (struct sockaddr*)&server_addr, sizeof(server_addr)) < 0) {
        perror("Connection failed");
        return 1;
    }

    // 1. WARMUP PHASE
    // The first few requests are always slow due to "Cold Start" penalties:
    //  - TCP Slow Start: The network window starts small and grows.
    //  - CPU Cache Misses: L1/L2 caches are empty.
    //  - Branch Predictor: The CPU hasn't learned the code path yet.
    //  - OS Context Switching: Waking up threads.
    //
    // We run 100 dummy requests to "warm up" the hot path before measuring.
    // Without this, the first ~50 requests would skew the results significantly.
    for (int i = 0; i < 100; i++) {
        std::string cmd = "GET warmup\n";
        send(sock, cmd.c_str(), cmd.size(), 0);
        char buf[1024];
        recv(sock, buf, sizeof(buf), 0);
    }

    // 2. REAL TEST (MEASUREMENT PHASE)
    char buffer[1024];
    for (int i = 0; i < NUM_REQUESTS; ++i) {
        std::string command = "GET key_" + std::to_string(i) + "\n";

        // Start Clock
        auto start = std::chrono::high_resolution_clock::now();

        send(sock, command.c_str(), command.size(), 0);
        recv(sock, buffer, sizeof(buffer), 0);

        // Stop Clock
        auto end = std::chrono::high_resolution_clock::now();

        // Calculate duration in Microseconds (us)
        // std::micro ensures we get sub-millisecond precision.
        std::chrono::duration<double, std::micro> elapsed = end - start;
        latencies.push_back(elapsed.count());
    }

    close(sock);

    // 3. STATISTICAL ANALYSIS
    // Sorting allows us to find percentiles easily.
    std::sort(latencies.begin(), latencies.end());

    double sum = std::accumulate(latencies.begin(), latencies.end(), 0.0);
    double avg = sum / latencies.size();
    double min_lat = latencies.front();
    double max_lat = latencies.back();
    double p50 = latencies[NUM_REQUESTS * 0.50];  // Median
    double p95 = latencies[NUM_REQUESTS * 0.95];  // 95% of reqs are faster than this
    double p99 = latencies[NUM_REQUESTS * 0.99];  // The "Tail Latency"

    std::cout << "------------------------------------------------------------\n";
    std::cout << "   RESULTS (Microseconds)\n";
    std::cout << "------------------------------------------------------------\n";
    std::cout << "Average:      " << avg << " us\n";
    std::cout << "Min:          " << min_lat << " us\n";
    std::cout << "Max:          " << max_lat << " us\n";
    std::cout << "------------------------------------------------------------\n";
    std::cout << "p50 (Median): " << p50 << " us\n";
    std::cout << "p95 (Fast):   " << p95 << " us\n";
    std::cout << "p99 (Tail):   " << p99 << " us\n";
    std::cout << "============================================================\n\n\n";

    return 0;
}