g++ -O3 -flto -march=native -pthread -std=c++17 -I./include src/main.cpp src/kv_store.cpp src/tcp_server.cpp -o kv_server

./kv_server