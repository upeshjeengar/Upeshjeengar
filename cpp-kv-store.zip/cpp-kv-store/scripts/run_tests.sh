#!/bin/bash
set -e  # Stop immediately if any command fails

echo "--- 1. INTEGRITY TESTS (Python) ---"
python3 tests/test_integrity.py

echo -e "\n--- 2. CHAOS TESTS (Python) ---"
python3 tests/test_stream_chaos.py

echo -e "\n--- 3. COMPILING & RUNNING THROUGHPUT BENCHMARK ---"
g++ -O3 -pthread tests/benchmark_throughput.cpp -o tests/bench_throughput
./tests/bench_throughput

echo -e "\n--- 4. COMPILING & RUNNING LATENCY BENCHMARK ---"
g++ -O3 -pthread tests/benchmark_latency.cpp -o tests/bench_latency
./tests/bench_latency

echo -e "\n--- 5. COMPILING & RUNNING ENDURANCE TEST ---"
g++ -O3 -pthread tests/test_endurance.cpp -o tests/test_endurance
./tests/test_endurance