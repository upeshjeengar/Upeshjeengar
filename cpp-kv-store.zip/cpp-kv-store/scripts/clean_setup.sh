#!/bin/bash
# Remove test binaries and data files without complaining if they are missing
rm -f tests/bench_throughput tests/bench_latency tests/test_endurance kvstore.aof kv_server

# Remove build directory
rm -rf build

echo "Cleanup complete."